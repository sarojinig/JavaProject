//Finding the length of the string
public class String3 {
public static void main(String [] args)
{
	String s1="ssarojini";
	System.out.println("string length is:"+s1.length());
	//Extract a string using Substring
	System.out.println(s1.substring(2));
	//Searching in strings using indexOf()
	int index=s1.indexOf("aro");
	System.out.println("insex of substring"+index);
}
}
