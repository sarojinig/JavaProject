//1. Write a class with a default constructor, one argument constructor and two argument
//constructors. Instantiate the class to call all the constructors of that class from a main
//class
public class Consructor {
	Consructor() {
		System.out.println("default constructor");
	}

	Consructor(int a) {
		System.out.println("one argument constructor");
	}

	Consructor(int a, int b) {
		System.out.println("two argument constructor");
	}

	public static void main(String[] args) {
		Consructor in = new Consructor();
		Consructor im = new Consructor(10);
		Consructor io = new Consructor(10, 20);
	}
}
