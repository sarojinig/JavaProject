
public class Interface1 implements publicinterface {
	public String name="saro";
public void a()
{
	System.out.println("method a");
}
public void b()
{
	System.out.println("method b");
}
public static void main(String [] args)
{
	Interface1 ob=new Interface1();
	System.out.println("interface variable:  "+publicinterface.name);
	System.out.println("class variable:  "+ob.name);
}
}
