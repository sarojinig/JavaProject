//Print static variables in Instance method
public class Static2 {
	static int rollno = 10;
	static int age = 20;

	public void show()
	{
		System.out.println(+Static2.rollno);
		System.out.println(+Static2.age);
	}
	
	public static void main(String [] args)
	{
		Static2 sc = new Static2();
		sc.show();
	}
}