
public interface interfaceinherit {
public String name="dsa";
}
