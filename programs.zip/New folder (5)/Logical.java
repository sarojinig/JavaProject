
public class Logical {
	public static void main(String[] args) {
		int a = 20;
		int b = 10;
		int c = 10;
		int d = 0;
		System.out.println(+a);
		System.out.println(+b);
		System.out.println(+c);
		if ((a < b) && (b == c)) {
			d = a + b + c;
			System.out.println(+d);
		} else
			System.out.println("false");
		if ((a < b) || (b < c)) {
			d = a + b + c;
			System.out.println(+d);
		} else
			System.out.println("false");
		if (!(a < b)) {
			System.out.println("true");
		} else
			System.out.println("false");
	}
}
