class A {
	public void add() {
		int a = 10;
		int b = 20;
		int c = a + b;
		System.out.println("adition claas a" + c);
	}

	public void dis() {
		System.out.println("class a");
	}

	public void dis1() {
		System.out.println("class a method");
	}
}

class B extends A {
	public void add() {
		int d = 20;
		int e = 30;
		int m = 10;
		int f = d + e + m;
		System.out.println("adition class b" + f);
	}

	public void display() {
		System.out.println("class b");
	}

	public void display1() {
		System.out.println("class b method");
	}
}

class C extends B {
	public void add() {
		int g = 100;
		int h = 30;
		int n = 5;
		int p = 5;
		int i = g + h + n + p;
		System.out.println("adition class c" + i);
	}

	public void details() {
		System.out.println("class c");
	}

	public void details1() {
		System.out.println("class c method");
	}
}

public class Inheritance {
	public static void main(String[] args) {
		A p = new A();
		B q = new B();
		C r = new C();
		p.dis();
		p.dis1();
		q.display();
		q.display1();
		r.details();
		r.details1();
		p.add();
		q.add();
		r.add();
		q.dis();
		r.display();
		A obj=new B();
		obj.add();
		B obj1=new C();
		obj1.add();
	}
}
