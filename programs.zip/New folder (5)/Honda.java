//1. Create an abstract class with abstract and non-abstract methods.
//2. Create a sub class for an abstract class. Create an object in the child class for the
//abstract class and access the non-abstract methods
//3. Create an instance for the child class in child class and call abstract methods
//4. Create an instance for the child class in child class and call non-abstract methods
abstract class Bike {
	abstract void run();

	void dis() {
	}
}
class Honda extends Bike {
	void run() {
		System.out.println("running safely");
	}

	void dis() {
		System.out.println("display");
	}

	public static void main(String args[]) {
		Bike obj = new Honda();
		obj.run();
		obj.dis();
		Honda h=new Honda();
		h.run();
		h.dis();
	}
}
