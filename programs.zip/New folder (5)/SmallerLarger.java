public class SmallerLarger {
	public static void main(String[] args) {
		int a = 20;
		int b = 10;
		int c = 30;
		if ((a > b) && (a > c)) {
			System.out.println("larger" + a);
		} else if (b > c) {
			System.out.println("larger" + b);
		} else
			System.out.println("larger" + c);
		if ((a < b) && (a < c)) {
			System.out.println("smaller" + a);
		} else if (b < c) {
			System.out.println("smaller" + b);
		} else
			System.out.println("smaller" + c);
	}
}
