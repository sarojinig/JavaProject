//10. Write a program to read data from excel

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;

public class JavaIo10 {
	public static void main(String args[]) throws IOException {
		//obtaining input bytes from a file  
		var fis = new FileInputStream(new File("A:\\Demo\\Students.xls"));
		System.out.println("Hello");
	}
}
