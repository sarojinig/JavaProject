
//14. Write a program to generate NoSuchMethodException

public class Exceptions14 {

	public static void main(String[] args) {
		Exceptions14 quiz = new Exceptions14();
	    try {
	      quiz.initQuestionnaire("question_tolkien.txt");
	    } catch (NoSuchMethodException e) {
	      e.printStackTrace();
	    }
	}
}
