//5. Write two methods with the same name, number of parameters and data type but
//different return Type.
public class MethodOverloading5 {
public int show(int a,int b)
{
	int c=a+b;
	System.out.println("add"+c);
	return c;
}
public String show(String s,String s1)
{
	String s2=s+s1;
	System.out.println("string"+s2);
	return s2;
}
public static void main(String[] args)
{
MethodOverloading5 mo=new MethodOverloading5();
mo.show(10, 20);
mo.show("sarojini","GGG");
}
}
