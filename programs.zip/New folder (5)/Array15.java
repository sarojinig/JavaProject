//15. Write a method to find number of even number and odd numbers in an array
public class Array15 {
	public static void main(String args[]){  
		int a[]={1,2,5,6,3,2};  
		int count_even=0;
		int count_odd=0;
		System.out.println("Odd Numbers:");  
		for(int i=0;i<a.length;i++){  
		if(a[i]%2!=0){  
		System.out.println(a[i]); 
		count_odd++;
		}  
		} 
		System.out.println(count_odd);
		System.out.println("Even Numbers:");  
		for(int i=0;i<a.length;i++){  
		if(a[i]%2==0){  
		System.out.println(a[i]);  
		count_even++;
		}
		}
		System.out.println(count_even);
		} 
	
}
