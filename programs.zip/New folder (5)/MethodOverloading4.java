//4. Write two methods with the same name and same number of parameters of different
//type and call from main method
public class MethodOverloading4 {
	void show(int a,String b)
	{
		a=123;
		b="sarojini";
		System.out.println("int and string");
	}
	void show(String s,char c)
	{
		System.out.println("string and char");
	}
	public static void main(String[] args)
	{
		MethodOverloading4 mo=new MethodOverloading4();
		mo.show(10, "sar");
		mo.show("sad",'h');
}
}
