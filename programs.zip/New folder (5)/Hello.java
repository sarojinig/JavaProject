public class Hello extends One {
	public static void main(String[] args) {
		System.out.println("helloworld");
		One h = new One();
		h.add();
		h.printname();
		h.variables();
		h.arthimetic();
		h.increment();
	}

}
