import java.util.Scanner;
public class OddEven {
	public static void main(String[] args) {
		try (Scanner s = new Scanner(System.in)) {
			int num1 = s.nextInt();
			if (num1 % 2 == 0) {
				System.out.println("given number is even" + num1);
			} else {
				System.out.println("given number is odd" + num1);
			}
		}
	}
}