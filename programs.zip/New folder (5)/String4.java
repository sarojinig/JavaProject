//Matching a String Against a Regular Expression With matches()
public class String4 {
public static void main(String [] args)
{
	String s1=new String("welcome to strings");
	System.out.println(s1);
	System.out.println("return value:");
	System.out.println(s1.matches("welcome(.*)"));
	System.out.println("Return value :");
	System.out.println(s1.matches("(.*)to(.*)"));
}
}
