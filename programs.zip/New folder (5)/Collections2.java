//2. Create a HashMap with at least 10 key value pairs of the Student ID and Name
//Insert a Key value mapping into the map
//Fetch the value of a Key
//Create a clone/copy of HashMap
//Check if the given Key is in the Map
//Check if the value is in the Map
//Check if the map is empty
//Print the size of the Map to the console
//Print all the Keys of the map to the console
//Print all the Keys of the map to the console
//Remove a specific Key-value pair
//Copy all the elements of the Map to another Map
import java.util.HashMap;

public class Collections2 {
	public static void main(String[] args) {
		// Create an empty hash map by declaring object
		// of string and integer type
		HashMap<String, Integer> map = new HashMap<>();

		// Adding elements to the Map
		// usiing standard add() method
		map.put("vishal", 10);
		map.put("sachin", 30);
		map.put("vaibhav", 20);
		// Print size and content of the Map
		System.out.println("Size of map is:- " + map.size());
		// Displaying the HashMap
		System.out.println("Initial Mappings are: " + map);
		// Getting the value of 20
		System.out.println("The Value is: " + map.get("sachin"));
		System.out.println("The cloned map look like this: " + map.clone());
		// Checking for the key_element '20'
		System.out.println("Is the key '20' present? " + map.containsKey("sachin"));
		HashMap<Integer, String> map1 = new HashMap<>();
		map1.put(1,"ssss");
		map1.put(2, "hhh");
		map1.put(3, "jjj");
		// Checking for the Value 'Geeks'
		System.out.println("Is the value 'ssss' present? " + map1.containsValue("ssss"));
		 // Checking for the emptiness of Map
        System.out.println("Is the map empty? " + map1.isEmpty());
     // Displaying the size of the map
        System.out.println("The size of the map is " + map1.size());
     // Removing the existing key mapping
        String returned_value = (String)map1.remove(2);
     // Displaying the new map
        HashMap<Integer, String> map2 = new HashMap<>();
        map2.putAll(map1);
        System.out.println("New map is: "+ map2);

	}
}