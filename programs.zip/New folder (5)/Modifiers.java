
public class Modifiers {
	public int age=21;
	public void details()
	{
		System.out.println("public methos");
	}
public static void main(String [] args)
{
	Modifiers mo=new Modifiers();
	mo.details();
}
}
