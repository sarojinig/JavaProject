//5. Write a program to throw exception with your own message
public class Exceptions5 {
	 void validate(int age) {
		if (age < 18)
			throw new ArithmeticException("not valid");
		else
			System.out.println("welcome to vote");
	}

	public static void main(String args[]) {
		Exceptions5 ex=new Exceptions5();
		ex.validate(13);
		System.out.println("rest of the code...");
	}
}
