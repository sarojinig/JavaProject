//Comparing strings using the methods equals(),
//equalsIgnoreCase(), startsWith(), endsWith() and compareTo()
//Trimming strings with trim()
//Replacing characters in strings with replace()
//Splitting strings with split()
public class String5 {
	public static void main(String[] args) {
		String s1 = "sssss";
		String s2 = "sssss";
		String s3 = "sssss";
		String s4="welcome to java";
		String s5="   trailing and leading spaces   ";
		System.out.println("comparing strings :" + s1.equals(s2));
		System.out.println("s1.equalsIgnoreCase(s3)-" + s1.equalsIgnoreCase(s3));
		System.out.println("s1.compareTo(s2): " + s1.compareTo(s2));
		System.out.println("startswith:"+s4.startsWith("welcome"));
		System.out.println("startswith:"+s4.startsWith("elcome"));
		System.out.println("endswith:"+s4.endsWith("java"));
		System.out.println("endswith:"+s4.endsWith("welcome"));
		System.out.println("trailing and leading spaces:"+s5.trim());
		String strrep=s4.replace('o', 'i');
		System.out.println("replacing string:"+strrep);
		//splits the string based on whitespace  
		String[] str=s4.split("\\s");
		for(String s:str) {
			System.out.println(s);
		}
	}
}
