
//Program to check whether a number is EVEN or ODD using switch
import java.util.Scanner;
public class SwitchEven {
	public static void main(String[] args) {
		try (Scanner s = new Scanner(System.in)) {
			int num = s.nextInt();
			switch (num % 2) {
			case 0:
				System.out.println("even");
				break;
			case 1:
				System.out.println("odd");
				break;

			}
		}
	}
}