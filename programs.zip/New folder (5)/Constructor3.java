//3. Apply private, public, protected and default access modifiers to the constructor
public class Constructor3 {
	public Constructor3() {
		System.out.println("default constructor");
	}

	private Constructor3(int a) {
		a=10;
		System.out.println("one argument constructor"+a);
	}

	protected Constructor3(int a, int b) {
		a=10;
		b=20;
		int c=a+b;
		System.out.println("two argument constructor"+c);
	}
	public static void main(String[] args)
	{
		Constructor3 i=new Constructor3();
		Constructor3 j= new Constructor3(10);
		Constructor3 k=new Constructor3(10,20);
	}
}
