import java.util.Scanner;

//Write a program to find the prime or not
public class Prime {
	public static void main(String[] args) {
		int i, p = 0;
		try (Scanner in = new Scanner(System.in)) {
			System.out.println("enter two numbers:");
			int num = in.nextInt();
			for (i = 1; i <= num; i++) {
				if (num % i == 0) {
					p++;
				}
			}
			if (p == 2)
				System.out.println("prime");
			else
				System.out.println("not prime");
		}
	}
}
