//4. Write constructors with return type int and String
//5. Try to call the constructor multiple times with the same object
public class Constructor4 {
public Constructor4(String name)
{
	name="sarojini";
	System.out.println(name);	
}
public Constructor4(int a,int b)
{
	a=10;
	b=20;
	int c=a+b;
	System.out.println(+c);
}
public static void main(String[] args)
{
	Constructor4 k=new Constructor4("ssss");
	//Constructor4 k=new Constructor4(10,20);
	//Exception in thread "main" java.lang.Error: Unresolved compilation problem: 
	//Duplicate local variable k
	Constructor4 j=new Constructor4(10,20);
}
}