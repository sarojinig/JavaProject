class WhileLoop {
  public static void main(String[] args) {

    // declare variables
    int i = 1;

    // while loop from 1 to 5
    while(i<=20) {
      System.out.println(i);
      i++;
    }
  }
}