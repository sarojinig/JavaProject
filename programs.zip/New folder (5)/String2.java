//Concatenating two strings using + operator
public class String2 {
public static void main(String [] args)
{
	String name="om"+"sai";
	System.out.println(name);
}
}
