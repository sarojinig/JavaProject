//Write a program to palindrome or not.
import java.util.Scanner;
public class Reverse {
public static void main(String [] args)
{
	int rev=0;
	int n1,m;
	try(Scanner s=new Scanner(System.in))
	{
	int n=s.nextInt();
	n1=n;
	while(n!=0)
	{
		m=n%10;
		rev=rev*10+m;
		n=n/10;
	}
if(n1==rev)
	System.out.println("palindrome"+n1);
else
	System.out.println("not a pallindrome"+n1);
}
}
}
