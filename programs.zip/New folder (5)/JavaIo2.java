 //2. Write a program to write text to .txt file using OutputStream
import java.io.FileOutputStream;  
public class JavaIo2 {
    public static void main(String args[]){    
           try{    
             FileOutputStream fout=new FileOutputStream("G:\\file.txt");    
             fout.write(65);    
             fout.close();    
             System.out.println("success...");    
            }catch(Exception e){System.out.println(e);}    
      }    
}  

