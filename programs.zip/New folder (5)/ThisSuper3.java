//3. Call constructor of the current class using this()
public class ThisSuper3 {
int a=10;
int b=20;
int c=a+b;
ThisSuper3()
{
	System.out.println(c);
	System.out.println("default constructor");
}
ThisSuper3(int d)
{
	this();
}
public static void main(String[] args)
{
ThisSuper3 th=new ThisSuper3(3);
}
}
