//Program for multiple if else statement(Largest number in 10,20 and 30)
public class MultipleIf {
public static void main(String [] args)
{
	int a=10;
	int b=20;
	int c=30;
	if(a>b)
	{
		if(a>c)
		{
			System.out.println("large"+a);
		}
		else
		{
			System.out.println("large"+c);
		}
	}
		else if(b>c)
		{
			System.out.println("large"+b);
		}
		else
		{
			System.out.println("large"+c);
		}
}
}
