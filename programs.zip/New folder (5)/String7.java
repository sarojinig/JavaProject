//Converting integer objects to Strings
public class String7 {
	public static void main(String args[]) {
		int a = 123;
		int b = -123;
		String str1 = Integer.toString(a);
		String str2 = Integer.toString(b);
		System.out.println("String str1 = " + str1);
		System.out.println("String str2 = " + str2);
		String s1="welcome";
		System.out.println("uppercase:"+s1.toUpperCase());
		System.out.println("lowercase:"+s1.toLowerCase());
	}
}
