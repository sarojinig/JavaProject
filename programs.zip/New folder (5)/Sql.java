import java.sql.SQLException;

public class Sql {
	private Object outputParameterResults;

	public void clearParameters() throws SQLException {
		synchronized (((Object) checkClosed()).getConnectionMutex()) {
			super.clearParameters();

			try {
				if (this.outputParameterResults != null) {
					var object = this.outputParameterResults.clone();
				}
			} finally {
				this.outputParameterResults = null;
			}
		}
	}

	private Object checkClosed() {
		// TODO Auto-generated method stub
		return null;
	}
}
