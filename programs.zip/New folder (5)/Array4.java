//4. Write a function to test if array contains a specific value
//17. Write a method to verify if the array contains two specified elements(12,23)
public class Array4 {
	public static boolean contains(int[] arr, int item) {
	      for (int n : arr) {
	         if (item == n) {
	            return true;
	         }
	      }
	      return false;
	   }
	   public static void main(String[] args) {
	          int[] my_array1 = {
	            1,2,3,4,5,6,7,8,9,10,11,12,13,14};
	      System.out.println(contains(my_array1, 2));
	      System.out.println(contains(my_array1, 5));
	      System.out.println(contains(my_array1, 12));
	      System.out.println(contains(my_array1, 23));
	   }
	}

