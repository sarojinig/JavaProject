//6. Print all the static, instance variables in main method

import java.util.Scanner;

public class Static6 {
	String s;
	int i;

	static String Name = "Jala";
	
	Static6(String name, int id) {
		this.s = name;
		this.i = id;
	}

	public void show() {
		System.out.println("Name:" + this.s);
		System.out.println("Id:" + this.i);
	}

	public static void main(String[] args) {
		try (Scanner scanner = new Scanner(System.in)) {
			System.out.print("enter Name:");
			String s = scanner.nextLine();

			System.out.print("enter id:");
			int i = scanner.nextInt();

			Static6 co = new Static6(s, i);

			co.show();
			System.out.println(Static6.Name);
		}
	}
}
