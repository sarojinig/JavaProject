import java.util.Scanner;
public class SwitchMaleFemale {
	public static void main(String[] args) {
		try (Scanner s = new Scanner(System.in)) {
			char gender = s.next().charAt(0);
			switch (gender) {
			case 'F':
			case 'f':
				System.out.println("female");
				break;
			case 'M':
			case 'm':
				System.out.println("male");
				break;
			default:
				System.out.println("unspecified");
			}
		}
	}
}