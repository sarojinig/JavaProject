
public class AccessModifiers {
	private int id = 123;
	private String name = "sar";
	private int age = 45;

	private void display() {
		System.out.println("private method 1");
	}

	public static void main(String[] args) {
		AccessModifiers am = new AccessModifiers();
		am.display();
		System.out.println(am.id);
		System.out.println(am.name);
		System.out.println(am.age);
	}
}
