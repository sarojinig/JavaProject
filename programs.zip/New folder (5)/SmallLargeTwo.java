
public class SmallLargeTwo {
	public static void main(String [] args)
	{
		int a=10;
		int b=20;
		if(a>b)
		{
			System.out.println("large"+a);
			}
		else if(b>a)
		{
			System.out.println("large"+b);
		}
		if(a<b)
		{
			System.out.println("small"+a);
			}
		else if(b<a)
		{
			System.out.println("small"+b);
		}
	}

}
