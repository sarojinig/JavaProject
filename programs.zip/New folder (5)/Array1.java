//1. Write a function to add integer values of an array
////////////
import java.util.Scanner;
public class Array1 {
public static void main(String[] args)
{
	int sum=0;
	try(Scanner s=new Scanner(System.in))
	{
	System.out.println("enter the size of an array");
	int n=s.nextInt();
	int [] array=new int[n];
	for(int i=0;i<n;i++)
	{
		System.out.println("enter elements");
		array[i]=s.nextInt();
		sum=sum+array[i];
	}
	System.out.println("sum"+sum);
}
}
}
