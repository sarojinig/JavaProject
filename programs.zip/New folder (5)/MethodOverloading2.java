//2. Write two methods with the same name but different number of parameters of different
//data type and call the methods from main method
public class MethodOverloading2 {
	void show(int a, String b) {

		System.out.println("two variables");
	}

	void show(int i, String j, int k) {
		System.out.println("three variables");
	}

	public static void main(String[] args) {
		MethodOverloading2 mo = new MethodOverloading2();
		mo.show(10, "sarojini");
		mo.show(1, "sar", 3);
	}
}
