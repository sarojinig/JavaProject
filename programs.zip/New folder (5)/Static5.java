//5. Call static methods in instance methods
public class Static5 {
	
	public static void show()
	{
		System.out.println("Hello_StaticMethod");
		System.out.println("Hi_StaticMethod");
	}
	
	public void showInstanceMethod()
	{
		Static5.show();
		System.out.println("Hello_InstanceMethod");
		System.out.println("Hi_InstanceMethod");
	}
	
	public static void main(String [] args)
	{
		Static5 sc = new Static5();
		sc.showInstanceMethod();
	}
}
