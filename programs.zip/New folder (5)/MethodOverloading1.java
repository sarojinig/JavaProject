//1. Write two methods with the same name but different number of parameters of same type
//and call the methods from main method
public class MethodOverloading1 {
void show(int a,int b)
{
	//a=10;
	//b=20;
	int c=a+b;
	System.out.println("two variables"+c);
}
void show(int i,int j,int k)
{
	//i=10;
	//j=20;
	//k=30;
	int l=i+j+k;
	System.out.println("three variables"+l);
}
public static void main(String[] args)
{
	MethodOverloading1 mo=new MethodOverloading1();
	mo.show(10, 10);
	mo.show(1, 2,3);
}
}
