
//9. Write a function to reverse an array of integer values
import java.util.Scanner;

public class Array9 {
	public static void main(String[] args) {
		try (Scanner s = new Scanner(System.in)) {
			System.out.println("enter size of the array");
			int n = s.nextInt();
			System.out.println("enter elements");
			int[] a = new int[n];
			for (int i = 0; i < n; i++) {
				a[i] = s.nextInt();
			}
			System.out.println("reverse of an array");
			for (int i = n - 1; i >= 0; i--) {
				System.out.println(a[i]);
			}
		}
	}
}