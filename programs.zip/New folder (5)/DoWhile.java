//Write a program to print 1 to 10 using the do-while loop statement
public class DoWhile {
	public static void main(String[] args) {
		int i = 1;
		do {
			System.out.println(+i);
			i++;
		} while (i <= 10);

	}
}
