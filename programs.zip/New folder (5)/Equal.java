
//program to equal and not equal operator
import java.util.Scanner;

class Equal {

	public static void main(String[] args) {
		try (Scanner in = new Scanner(System.in)) {
			System.out.println("enter two numbers:");
			int num1 = in.nextInt();
			int num2 = in.nextInt();
			if (num1 == num2) {
				System.out.println("equal");
			} else if (num1 != num2) {
				System.out.println("not equal");
			}

		}
	}
}