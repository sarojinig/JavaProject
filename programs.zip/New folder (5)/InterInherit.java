
public class InterInherit implements interfaceinherit2 {
public static void main(String[] args)
{
	InterInherit ih=new InterInherit();
	System.out.println(interfaceinherit.name);
}
}
