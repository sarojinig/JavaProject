//1.Print the fields/instance members of the current class using this and without using object
public class ThisSuper1 {
int a;
int b;
public void set(int a,int b)
{
	this.a=a;
	this.b=b;
}
public void get()
{
	System.out.println("variable1  "+a);
	System.out.println("variable2  "+b);
}
public static void main(String[] args)
{
	ThisSuper1 ts=new ThisSuper1();
	ts.set(10, 10);
	ts.get();
}
}
