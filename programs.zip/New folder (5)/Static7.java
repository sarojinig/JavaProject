// 7. Call static methods and instance methods in main method
public class Static7 {

	public void Show() {
		System.out.println("Calling instance method.");
	}

	public static void ShowStatic() {
		System.out.println("Calling static method.");
	}

	public static void main(String[] args) {
		Static7 obj = new Static7();
		obj.Show();
		Static7.ShowStatic();
	}
}
