
public interface interfaceinherit2 extends interfaceinherit {
public int a=20;
}
