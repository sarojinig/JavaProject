//2. Call the constructors(both default and argument constructors) of super class from a child
//class
class Inherit {
	Inherit() {
		System.out.println("default constructor");
	}

	Inherit(int a) {
		System.out.println("one argument constructor");
	}

	Inherit(int c, int b) {
		System.out.println("two argument constructor");
	}
}

class Inherit1 extends Inherit {
	Inherit1() {
		super();
	}
}

public class Constructro2 {

	public static void main(String[] args) {
		Inherit1 h = new Inherit1();
	}
}
// Inherit h=new Inherit();
