//10. Create an interface with private, public and protected fields.
//11. Create an interface with static final variable

public interface interface9 {
public String name="sar";
//private String name1="sar";
//protected String name2="sar";//only public static and final are permitted
static final int a=10;
}
