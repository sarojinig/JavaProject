
public interface printable {
void print();
void print1();
void print2();
default void print3()
{
	
}
}
