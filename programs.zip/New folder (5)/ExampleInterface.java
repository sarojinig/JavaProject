//Create an interface with only one method and implement it in a class. Call the method
//implemented.
//Create an interface with two methods, but implement only one in a class. Call the
//method implemented.
//Use Interface instances to call the implemented method in the implemented class
//Create two interfaces with one method each. Implement these two interfaces in one
//class
//Create two interfaces with the same method (same signature) in both the interfaces.
//Implement these two interfaces in one class. Call the method.
//Create an interface with a default method and implement it in a class. Do not provide
//implementation to the default method and call the method.

public class ExampleInterface implements printable, display {
	public void print() {
		System.out.println("interface");
	}

	public void dis() {
		System.out.println("interface1");
	}

	public void print2() {
		System.out.println("interface2");
	}

	public static void main(String[] args) {
		ExampleInterface ei = new ExampleInterface();
		ei.print();
		ei.dis();
		ei.print2();
		ei.print3();
	}
}
