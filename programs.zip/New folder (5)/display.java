
public interface display extends printable {
void dis();
void print2();
}
