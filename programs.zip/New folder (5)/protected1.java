public interface protected1 {
final static String name="sarojini";
int rollno=1234;
void show();
}
