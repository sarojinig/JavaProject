//Converting Numbers to Strings with valueOf()
public class String6 {
	public static void main(String[] args) {
		int i = 10;
		String s = String.valueOf(i);
		System.out.println(i + 10);// + is binary plus operator
		System.out.println(i + s);// + is string concatenation operator
	}
}
