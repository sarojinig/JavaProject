
//Write a program to find Armstrong number or not
import java.util.Scanner;

public class Armstrong {
	public static void main(String[] args) {
		int n;
		int n1 = 0;
		int m;
		int t = 0;
		try (Scanner s = new Scanner(System.in)) {
			System.out.println("enter the number");
			n = s.nextInt();
			n1 = n;
			while (n > 0) {
				m = n % 10;
				t = t + (m * m * m);
				n = n / 10;
			}
			if (t == n1)
				System.out.println("the given number is arm strong" + n1);
			else
				System.out.println("the given number is not arm strong" + n1);
		}
	}
}
