//4. Call instance methods in static methods
public class Static4 {

	static int rollno = 10;
	static int age = 20;

	public void show()
	{
		System.out.println(+Static4.rollno);
		System.out.println(+Static4.age);
	}
	
	public static void main(String [] args)
	{
		Static4 sc = new Static4();
		sc.show();
	}
}
