//Different ways creating a string
public class String1 {
public static void main(String [] args)
{
	String name="siva";
	String course="bsc";
	System.out.println("String name="+name);
	System.out.println("String course="+course);
}
}
