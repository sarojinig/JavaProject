//define a method
public class One  {
public int add(){
	int a=10;
	int b=15;
	int c=a+b;
	System.out.println("addition"+c);
	return c;
}

	
//local and global
int k=2;
public void variables()
{
	int k=5;
	System.out.println("print k value"+k);
}

//print your name
public void  printname()
{	
	for(int i=1;i<=10;i++)
	{
		System.out.println("sarojini");
	}
}
//single line comment
/*multi line comment*/
/**documentation comment*/

//arthimetic operators
public void arthimetic()
{
int a=10;
int b=5;
System.out.println("addition"+(a+b));
System.out.println("substraction"+(a-b));
System.out.println("multiplication"+(a*b));
System.out.println("divison"+(a/b));
}

//increment and decrement
public void increment()
{
	int i=5;
	System.out.println("increment"+(i++));
	System.out.println(i);
	System.out.println("increment"+(++i));
	System.out.println("decrement"+(i--));
	System.out.println(i);
	System.out.println("increment"+(--i));

}

}	
