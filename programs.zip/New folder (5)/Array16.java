import java.util.Scanner;

public class Array16 {
	static int[] getMinMax(int a[], int n) {
		int min, max, i;
		min = max = a[0];
		for (i = 1; i < n; i++) {
			if (min > a[i])
				min = a[i];
			if (max < a[i])
				max = a[i];
		}
		System.out.println("minimum value" + min);
		System.out.println("maximum value" + max);
		System.out.println("difference is" +(max-min));
		int res[] = { min, max };
		return res;
	}

	public static void main(String[] args) {
		int n;
		try (Scanner s = new Scanner(System.in)) {
			System.out.print("Enter size of an array:");
			n = s.nextInt();
			int a[] = new int[n];
			System.out.println("enter elements");
			for (int i = 0; i < n; i++) {
				a[i] = s.nextInt();
			}

			getMinMax(a, n);
		}
	}
}
