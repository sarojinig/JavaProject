//4. Call argument constructor of current class using this()
public class ThisSuper4 {
	int a=10;
	int b=20;
	int c=a+b;
	ThisSuper4()
	{
		this(5);
		System.out.println(c);
		System.out.println("default constructor");
	}
	ThisSuper4(int d)
	{
		System.out.println(c);
		System.out.println("argument constructor");
	}
	public static void main(String[] args)
	{
	ThisSuper4 th=new ThisSuper4();
	}

}
