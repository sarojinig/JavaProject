//6. Use this() and super() in methods not in constructors
public class ThisSuper6 {
public void show()
{
	System.out.println("method1");
}
public void show1()
{
	//both this() and super() can not be used together in constructor. 
	//this() is used to call default constructor of same class.it should be first statement inside constructor. 
	//super() is used to call default constructor of base class.it should be first statement inside constructor.

}
}
