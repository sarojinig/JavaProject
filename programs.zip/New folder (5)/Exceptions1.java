//1. Write a program to generate Arithmetic Exception without exception handling
public class Exceptions1 {
	public static void main(String args[]) {
		int num1 = 30, num2 = 0;
		int num3 = num1 / num2;
		System.out.println("Result: " + num3);
	}
}