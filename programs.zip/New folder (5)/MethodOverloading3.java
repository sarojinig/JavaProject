//3. Write two methods with the same name and same number of parameters of same type
//and call from main method
public class MethodOverloading3 {
	void show(int a,int b)
	{
		//a=10;
		//b=20;
		int c=a+b;
		System.out.println("two variables"+c);
	}
	void show(int a,int b)
	{
		//i=10;
		//j=20;
		//k=30;
		int l=a+b;
		System.out.println("variables"+l);
	}
	public static void main(String[] args)
	{
		MethodOverloading1 mo=new MethodOverloading1();
		mo.show(10, 10);
		mo.show(1,3);
}
}
//this will throw compilation error