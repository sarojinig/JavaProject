//Create a PRIVATE or PROTECTED interface and print the values as above scenario
public class Protected implements protected1 {
	protected String name="saro";
	public void show()
	{
		System.out.println("method a");
	}
		public static void main(String [] args)
	{
		Protected ob=new Protected();
		System.out.println("interface variable:  "+protected1.name);
		System.out.println("class variable:  "+ob.name);
		ob.show();
	}
	}


	