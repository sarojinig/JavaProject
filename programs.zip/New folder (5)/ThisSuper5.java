//5. Call constructor of the parent class using super()
class Parent1
{
	Parent1()
	{
		System.out.println("parent class constructor");
	}
}
class Child1 extends Parent1
{
	Child1()
	{
		super();
	}
}
public class ThisSuper5 {
	public static void main(String[] args)
	{
		Child1 c=new Child1();
	}

}
