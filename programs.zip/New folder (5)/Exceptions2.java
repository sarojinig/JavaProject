//2. Handle the Arithmetic exception using try-catch block
public class Exceptions2 {
	public static void main(String args[]) {
		try {
			int num1 = 30, num2 = 0;
			int num3 = num1 / num2;
			System.out.println("Result: " + num3);
		} catch (ArithmeticException e) {
			System.out.println("You Shouldn't divide a number by zero");
		}
	}
}
