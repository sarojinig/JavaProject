// Adds the Interface to the Package
package Calculator;

//Interface Definition
interface iCalc 
{
	public void doCalculation();
	public void getResult();
}

