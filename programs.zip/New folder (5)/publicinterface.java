//Create a PUBLIC interface with fields and methods, fields should have values assigned.
//Implement this interface to some class and print the values of the interface fields and
//call the interface methods
public interface publicinterface {
public String name="sar";
public int rollno=123;
void a();
void b();
}
