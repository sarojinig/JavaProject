//Print instance variables in static methods public class Static1 { //int

import java.util.*;

public class Static1 {
    String s;
    int i;

    Static1(String name, int id) {
        this.s = name;
        this.i = id;
    }

    public void show() {
        System.out.println("Name:" + this.s);
        System.out.println("Id:" + this.i);
    }

    public static void main(String[] args) {
        try (Scanner scanner = new Scanner(System.in)) {
			System.out.print("enter Name:");
			String s = scanner.nextLine();

			System.out.print("enter id:");
			int i = scanner.nextInt();

			Static1 co = new Static1(s, i);
			
			co.show();
		}
        }
    }
