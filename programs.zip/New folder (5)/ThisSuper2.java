//2. Print the fields/instance members of the parent class using super
class Parent
{
	int a=123;
}
class Child extends Parent
{
	int a=436;
	public void show()
	{
		System.out.println(a);
		System.out.println(super.a);
	}
}
public class ThisSuper2 {
public static void main(String[] args)
{
	Child ts=new Child();
	ts.show();
}
}
