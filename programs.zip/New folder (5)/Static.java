//Write a class with 2 static variables, 2 Instance variables, 2 static methods, 2 instance
//methods and a main method
public class Static {
	//static variables
static String name;
static int age;
//instance variables
public int rollno;
public String gender;
//static methods
static void dis()
{
	System.out.println("name:"+name);
}
static void display()
{
	System.out.println("age:"+age);
}
//instance methods
public void details()
{
	rollno=123;
	System.out.println("rollno:"+rollno);
}
public void details1()
{
	gender="female";
	System.out.println("gender:"+gender);
}
public static void main(String [] args)
{
	name="sarojini";
	dis();
	age=26;
	display();
	Static st=new Static();
	st.details();
	st.details1();
}
}
