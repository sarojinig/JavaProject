//1. Create an ArrayList of type String with 10 string elements. Add 10 string elements to
//ArrayList and perform the below operations
//Add an element to the ArrayList
//Iterate through the ArrayList by using Iterator object
//Add an element at a specific index
//Remove an element from the ArrayList, Remove at an index
//Update the element at a specific index
//Check the element is present at a particular index
//Get an element at a particular index
//Find out the size of the ArrayList
//Check the given element is present in the ArrayList
//Remove all elements of the ArrayList

import java.util.*;
public class Collection1 {
	public static void main(String[] args) {
	ArrayList<String> alist=new ArrayList<String>(10);  
    alist.add("Steve");
    alist.add("Tim");
    alist.add("Lucy");
    alist.add("Pat");
    alist.add("Angela");
    alist.add("Tom");
    alist.add("sar");
    alist.add("sss");
    alist.add("jan");
    alist.add("jala");
    System.out.println(alist);
    alist.add(4, "raj");
    System.out.println(alist);
    for(int i = 0; i < alist.size(); i++)
    {
        System.out.println(alist.get(i));
    }
    alist.remove(2);
    System.out.println(alist);
    alist.set(0, "lane");
    System.out.println(alist);
    if(alist.contains("Tim"))
    {
    	System.out.println("element is present");
    }
    else
    {
    	System.out.println("element is not present");
    }
    if(alist.indexOf("jala")>=0)
        System.out.println("exists in the ArrayList");
        
      else
        System.out.println("does not exist in the ArrayList");
    String firstName=alist.get(0);
    String secondName=alist.get(1);
    System.out.println(firstName);
    System.out.println(secondName);
    System.out.println("The size of the ArrayList is: " + alist.size());
    System.out.println("The element raj is available in ArrayList? " + alist.contains("raj"));
    alist.clear();
    System.out.println(alist);
}
}
